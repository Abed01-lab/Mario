// @Abed
// @Sumit
// @ Gustav

package mariospizza;

import java.io.IOException;

public class MariosPizza {

    public static void main(String[] args) throws IOException {
        Udføre udføre = new Udføre();
        
        udføre.startProgram();

    }
}
