// @Abed
// @Sumit
// @ Gustav

package mariospizza;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;

public class UdføreTest {

    //Tester om det der bliver tilføjede det korrekte antal
    @Test
    public void tilføjBestillingTilListe() {
        //Arrange
        BestillingsListe bestillingsListe = new BestillingsListe();
        Menu menu = new Menu();
        Omsætning omsætning = new Omsætning();

        int antal = 6;
        int nr = 2;

        //Act
        for (int i = 0; i < antal; i++) {
            bestillingsListe.tilføj(menu.menu[nr - 1]);
            omsætning.tilføj(menu.menu[nr - 1]);
        }

        //Assert
        assertEquals(antal, bestillingsListe.bestillingsListe.size());
        assertEquals(antal, omsætning.omsætningsListe.size());

    }

    //Tester om alle pizza i omsætningslisten bliver printet
    @Test
    public void eksportereOmsætningTiltxtTest() throws IOException {
        //Arrange
        Omsætning omsætning = new Omsætning();
        Menu menu = new Menu();
        File file = new File("Omsætning.text");
        BufferedWriter bw = new BufferedWriter(new FileWriter(file));
        Scanner scan = new Scanner(file);

        int antal = 10;
        int nr = 1;
        int expectedLinjes = 0;
        String str;

        //Act
        for (int i = 0; i < antal; i++) {
            omsætning.tilføj(menu.menu[nr - 1]);
        }
        
         int maxCounter = 0;
        Pizza favoritePizza = new Pizza("Vesuvio", 1, 57);

        for (int i = 0; i < omsætning.omsætningsListe.size(); i++) {
            int counter = 1;
            for (int j = 0; j < omsætning.omsætningsListe.size(); j++) {
                if (omsætning.omsætningsListe.get(i) == omsætning.omsætningsListe.get(j)) {
                    counter++;
                }
            }

            if (maxCounter < counter) {
                maxCounter = counter;
                favoritePizza = (Pizza) omsætning.omsætningsListe.get(i);
            }
        }
        
        

        bw.write("Pizza: \n");
        for (Pizza pizza : omsætning.omsætningsListe) {
            bw.write(pizza.toString());
            bw.newLine();
        }
        
        bw.write("Total omsætning: " + omsætning.beregn());
        bw.write("\n");
        bw.write("\nFarvorit Pizza: " + favoritePizza.pizzaNavn + ", antal: " + maxCounter);
        bw.close();
        
        while (scan.hasNextLine()) {
            str = scan.nextLine();
            expectedLinjes++;
        }
        
        //Assert
        assertEquals(expectedLinjes, omsætning.omsætningsListe.size() + 4);
    }
}
