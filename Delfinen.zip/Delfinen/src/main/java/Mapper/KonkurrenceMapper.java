package Mapper;


public class KonkurrenceMapper {

	public void tilføjMedlemRygCrawl() {
	}

	public void tilføjMedlemButterfly() {
	}

	public void tilføjMedlemCrawl() {
	}

	public void tilføjMedlemBrystsvømning() {
	}

	public void seTop5() {
	}
        
	public void tilføjPlacering() {
           
	}

	public void tilføjStævne() {
	}

	public void tilføjTid() {
	}

}