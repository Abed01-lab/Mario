package Model;
public class Kontingent {

	public void UdregnKontingent() {
	}

	public void PrintMeldlemmerIGæld() {
	}

}