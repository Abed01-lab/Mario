package Model;


public class Medlem {

	private String navn;
	private int alder;
	private int tlf;
	private String adresse;
	private boolean status;
	private int kontingent;
	private int gæld;

    public Medlem(String navn, int alder, int tlf, String adresse, boolean status) {
        this.navn = navn;
        this.alder = alder;
        this.tlf = tlf;
        this.adresse = adresse;
        this.status = status;
    }

	public String getNavn() {
		return this.navn;
	}

	public void setNavn(String navn) {
		this.navn = navn;
	}

	public int getAlder() {
		return this.alder;
	}

	public void setAlder(int alder) {
		this.alder = alder;
	}

	public int getTlf() {
		return this.tlf;
	}

	public void setTlf(int tlf) {
		this.tlf = tlf;
	}

	public String getAdresse() {
		return this.adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public boolean getStatus() {
		return this.status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public int getKontingent() {
		return this.kontingent;
	}

	public void setKontingent(int kontingent) {
		this.kontingent = kontingent;
	}

	public int getGæld() {
		return this.gæld;
	}

	public void setGæld(int gæld) {
		this.gæld = gæld;
	}

	public void ToString() {
	}


}