package mariospizza;

public class MariosPizza {

    public static void main(String[] args) {
        Udføre udføre = new Udføre();
        
        udføre.startProgram();

    }
}
