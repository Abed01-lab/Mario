package mariospizza;

import java.io.IOException;
import java.util.Scanner;
import java.util.Collections;

public class Udføre {

    boolean erKlarTilAtOrdreIgen = true;
    boolean vilHaveMere = true;

    BestillingsListe bestillingsListe = new BestillingsListe();
    Omsætning omsætning = new Omsætning();
    Menu menu = new Menu();
    

    private void startText() {
        System.out.println("\nIndtast: ");
        System.out.println("1. Opret bestilling");
        System.out.println("2. Fjern en bestilling");
        System.out.println("3. Se Bestillings Liste");
        System.out.println("4. Se Menu");
        System.out.println("5. Se omsætning");
        System.out.println("6. Eksportere omsætning");

    }

    public void startProgram() throws IOException {

        while (true) {

            startText();
            Scanner input = new Scanner(System.in);
            int swichInput = input.nextInt();

            switch (swichInput) {

                //Opret Ordre
                case 1:
                    while (erKlarTilAtOrdreIgen) {
                        System.out.println("Hvilken pizza nr vil du tilføje?");
                        int pizzaNr = input.nextInt();

                        if (pizzaNr > 14 || pizzaNr < 1) {
                            System.out.println("ERROR 404!");
                            break;
                        }

                        System.out.println("Hvor mange vil du tilføje");
                        int antal = input.nextInt();

                        if (antal <= 0) {
                            System.out.println("antal er ugyldig...");
                            break;
                        }

                        System.out.println("Hvornår skal orden afhentes?");
                        int afhentTid = input.nextInt();

                        if (afhentTid > 2400 || afhentTid < 0) {
                            System.out.println("uglydlig tid");
                            break;
                        }

                        if (antal > 0) {
                            for (int i = 0; i < antal; i++) {
                                bestillingsListe.tilføj(menu.menu[pizzaNr - 1]);
                                omsætning.tilføj(menu.menu[pizzaNr - 1]);
                                menu.menu[pizzaNr - 1].afhentningsTid = afhentTid;

                            }
                            System.out.println("Vil du tilføje mere...");
                            System.out.println("1 for ja, 2 for nej");
                            int svar = input.nextInt();
                            if (svar == 1) {
                                erKlarTilAtOrdreIgen = true;
                            } else {
                                erKlarTilAtOrdreIgen = false;
                                break;
                            }
                        } else {
                            System.out.println("Ugyldig tal...");
                        }

                    }
                    break;

                //Fjern bestilling
                case 2:
                    bestillingsListe.printListe();
                    System.out.println("Indtast pizza nr for at fjerne");
                    int pizzaNr1 = input.nextInt();

                    bestillingsListe.fjern(pizzaNr1);
                    bestillingsListe.printListe();
                    break;

                //Print bestillingsListe
                case 3:
                    Collections.sort(bestillingsListe.bestillingsListe);
                    bestillingsListe.printListe();
                    break;

                //Print Menu
                case 4:
                    menu.arrayPrint();
                    break;

                //Omsætning
                case 5:
                    omsætning.printListe();
                    System.out.println(omsætning.beregn());

                    break;
                    
                //Eksportere omsætning til textfil
                case 6:
                    omsætning.exportereOmsætningTilFil();
                    break;

            }
        }
    }

    public void tilføjeOrdre(int nr, int antal) {
        for (int i = 0; i < antal; i++) {
            bestillingsListe.tilføj(menu.menu[nr - 1]);
        }
    }
}
