package mariospizza;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Omsætning {

    ArrayList<Pizza> omsætningsListe = new ArrayList<Pizza>();

    public int beregn() {
        int sum = 0;
        for (Pizza pizza : omsætningsListe) {
            sum = sum + pizza.getPris();
        }
        return sum;
    }

    public void tilføj(Pizza pizza) {
        omsætningsListe.add(pizza);
    }

    public void printListe() {
        if (omsætningsListe.size() != 0) {
            int i = 0;
            for (Pizza pizza : omsætningsListe) {
                i++;
                System.out.println(i + ". Pizza: " + pizza.getPizzaNavn() + ", afhentnignstid: KL " + pizza.getAfhentingsTid());
            }
        } else {
            System.out.println("Ingen bestillinger...");
        }
    }

    public void exportereOmsætningTilFil() throws IOException {
        File file = new File("Omsætning.text");
        BufferedWriter bw = new BufferedWriter(new FileWriter(file));
        bw.write("Pizza:\n");
        for (Pizza pizza : omsætningsListe) {
            bw.write(pizza.toString());
            bw.newLine();
        }

        bw.write("Total omsætning: " + beregn() + " kr.");
        bw.close();
    }
}
